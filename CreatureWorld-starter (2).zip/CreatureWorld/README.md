# CreatureWorld starter (Unity 2022 LTS or Unity 6)

## Setup
1. Unity Hub > New 3D (URP) project > copy `Assets/Scripts` into it.
2. Package Manager > add `com.unity.netcode.gameobjects` (Netcode for GameObjects).
3. Player prefab: Capsule + CharacterController + NetworkObject +
   ClientNetworkTransform + PlayerController. Add a camera pivot child.
4. Empty scene object: NetworkManager (assign Player prefab, Unity Transport)
   + NetworkBootstrap.
5. Create content: Assets > Create > CreatureWorld > Move / Creature Species.
   Make 3 original creatures (e.g. Emberfox / Aquadrake / Leafwing) to test.
6. Test multiplayer: Build & Run one instance, Play in editor, Host + Join.

## Android build
File > Build Settings > Android; Scripting Backend IL2CPP; ARM64 only;
Graphics APIs Vulkan + GLES3; build an App Bundle (AAB) for Play Store.

## Next steps
- Wild encounter zones + battle UI
- Touch controls (Input System on-screen stick)
- World streaming (Addressables), quality tiers, LODs
- Dedicated server + PlayFab/Firebase for accounts and saved creatures
