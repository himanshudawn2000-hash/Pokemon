using Unity.Netcode;
using UnityEngine;

// Temporary Host/Join buttons for testing. Replace with lobby/matchmaking later.
public class NetworkBootstrap : MonoBehaviour
{
    void OnGUI()
    {
        var nm = NetworkManager.Singleton;
        if (nm == null || nm.IsClient || nm.IsServer) return;
        GUILayout.BeginArea(new Rect(20, 20, 200, 150));
        if (GUILayout.Button("Host"))   nm.StartHost();
        if (GUILayout.Button("Join"))   nm.StartClient();
        if (GUILayout.Button("Server")) nm.StartServer();
        GUILayout.EndArea();
    }
}
