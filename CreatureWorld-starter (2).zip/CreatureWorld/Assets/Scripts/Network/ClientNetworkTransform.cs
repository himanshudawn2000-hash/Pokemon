using Unity.Netcode.Components;

// Lets the owning client move its own player (responsive).
// For competitive modes, validate positions on the server.
public class ClientNetworkTransform : NetworkTransform
{
    protected override bool OnIsServerAuthoritative() => false;
}
