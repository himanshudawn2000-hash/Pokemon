using UnityEngine;

public struct TurnResult
{
    public int damage; public bool hit; public float effectiveness; public bool crit;
}

public static class BattleSystem
{
    public static TurnResult UseMove(CreatureInstance atk, CreatureInstance def, MoveData move)
    {
        var r = new TurnResult { hit = Random.Range(0, 100) < move.accuracy };
        if (!r.hit) return r;

        r.effectiveness = TypeChart.Multiplier(move.type, def.species.type);
        r.crit = Random.value < 0.0625f;
        float stab = move.type == atk.species.type ? 1.5f : 1f;
        float rand = Random.Range(0.85f, 1f);

        float baseDmg = ((2f * atk.level / 5f + 2f) * move.power * atk.Attack / def.Defense) / 50f + 2f;
        r.damage = Mathf.Max(r.effectiveness == 0 ? 0 : 1,
            Mathf.FloorToInt(baseDmg * stab * r.effectiveness * (r.crit ? 1.5f : 1f) * rand));

        def.currentHP = Mathf.Max(0, def.currentHP - r.damage);
        return r;
    }

    // Faster creature moves first
    public static bool PlayerGoesFirst(CreatureInstance p, CreatureInstance e) => p.Speed >= e.Speed;

    // Lower HP + higher catchRate = easier capture
    public static bool TryCatch(CreatureInstance wild, float ballBonus = 1f)
    {
        float hpFactor = (3f * wild.MaxHP - 2f * wild.currentHP) / (3f * wild.MaxHP);
        float chance = Mathf.Clamp01(hpFactor * (wild.species.catchRate / 255f) * ballBonus);
        return Random.value < chance;
    }
}
