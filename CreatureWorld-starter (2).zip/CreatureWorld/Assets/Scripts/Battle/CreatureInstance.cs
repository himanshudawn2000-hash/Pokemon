using System;
using UnityEngine;

[Serializable]
public class CreatureInstance
{
    public CreatureSpecies species;
    public int level = 5;
    public int currentHP;
    public string nickname;

    public int MaxHP   => Mathf.FloorToInt((2 * species.baseHP * level) / 100f) + level + 10;
    public int Attack  => Stat(species.baseAttack);
    public int Defense => Stat(species.baseDefense);
    public int Speed   => Stat(species.baseSpeed);
    public bool Fainted => currentHP <= 0;

    int Stat(int b) => Mathf.FloorToInt((2 * b * level) / 100f) + 5;

    public CreatureInstance(CreatureSpecies s, int lvl)
    {
        species = s; level = lvl; currentHP = MaxHP;
    }
}
