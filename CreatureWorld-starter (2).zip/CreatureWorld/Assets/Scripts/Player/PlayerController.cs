using Unity.Netcode;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : NetworkBehaviour
{
    public float walkSpeed = 4f, runSpeed = 8f, turnSpeed = 12f, gravity = -20f;
    public Transform cameraPivot;

    CharacterController cc;
    float vy;

    public override void OnNetworkSpawn()
    {
        cc = GetComponent<CharacterController>();
        // Only the owner reads input and owns a camera
        if (!IsOwner && cameraPivot) cameraPivot.gameObject.SetActive(false);
        enabled = IsOwner;
    }

    void Update()
    {
        Vector2 input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        Transform cam = Camera.main.transform;
        Vector3 fwd = Vector3.ProjectOnPlane(cam.forward, Vector3.up).normalized;
        Vector3 right = Vector3.ProjectOnPlane(cam.right, Vector3.up).normalized;
        Vector3 dir = (fwd * input.y + right * input.x).normalized;

        float speed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;
        vy = cc.isGrounded ? -1f : vy + gravity * Time.deltaTime;

        if (dir.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(dir), turnSpeed * Time.deltaTime);

        cc.Move((dir * speed + Vector3.up * vy) * Time.deltaTime);
    }
}
