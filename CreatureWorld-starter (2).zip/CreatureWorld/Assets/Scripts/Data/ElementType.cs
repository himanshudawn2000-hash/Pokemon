using UnityEngine;

public enum ElementType { Normal, Fire, Water, Grass, Electric, Earth, Wind, Shadow }

public static class TypeChart
{
    // rows = attacker, cols = defender (order matches ElementType)
    static readonly float[,] chart =
    {
        //          Nor  Fire Wat  Gra  Ele  Ear  Win  Sha
        /*Normal*/  {1f, 1f,  1f,  1f,  1f,  1f,  1f,  1f },
        /*Fire*/    {1f, .5f, .5f, 2f,  1f,  1f,  1f,  1f },
        /*Water*/   {1f, 2f,  .5f, .5f, 1f,  2f,  1f,  1f },
        /*Grass*/   {1f, .5f, 2f,  .5f, 1f,  2f,  .5f, 1f },
        /*Electric*/{1f, 1f,  2f,  .5f, .5f, 0f,  2f,  1f },
        /*Earth*/   {1f, 2f,  1f,  .5f, 2f,  1f,  0f,  1f },
        /*Wind*/    {1f, 1f,  1f,  2f,  .5f, 1f,  1f,  1f },
        /*Shadow*/  {1f, 1f,  1f,  1f,  1f,  1f,  1f,  .5f},
    };

    public static float Multiplier(ElementType atk, ElementType def) => chart[(int)atk, (int)def];
}
