using UnityEngine;

[CreateAssetMenu(menuName = "CreatureWorld/Creature Species")]
public class CreatureSpecies : ScriptableObject
{
    public int id;
    public string displayName;
    public ElementType type;
    public int baseHP = 45, baseAttack = 49, baseDefense = 49, baseSpeed = 45;
    [Range(1, 255)] public int catchRate = 120;
    public MoveData[] learnset;
    public GameObject modelPrefab;   // your original 3D model goes here
}
