using UnityEngine;

[CreateAssetMenu(menuName = "CreatureWorld/Move")]
public class MoveData : ScriptableObject
{
    public string moveName;
    public ElementType type;
    [Range(0, 200)] public int power = 40;
    [Range(1, 100)] public int accuracy = 95;
}
